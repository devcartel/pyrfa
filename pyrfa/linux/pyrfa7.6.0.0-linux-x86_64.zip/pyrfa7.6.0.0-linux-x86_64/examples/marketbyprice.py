#!/usr/bin/python
#
# This file illustrates the example how to request OMMlevel2 data using marketByPriceRequest
# The sample published data is mentioned below:
#
# Sample:
#   ('NIP', 'ANZ.CHA', 'REFRESH')
#   ('NIP', 'ANZ.CHA', 'ADD', ('210000B', {'ORDER_SIDE': 'ASK', 'ORDER_TONE': '',
#   'ORDER_PRC': 21.0, 'NO_ORD': 13, 'QUOTIM_MS': 16987567, 'ORDER_SIZE': 500.0}))
#   (('NIP','ANZ.CHA','UPDATE',('201000B',{'ORDER_SIDE':'BID','ORDER_SIZE':60,'NO_ORD':7})))
#
import sys
sys.path.append('../lib')

import pyrfa
p = pyrfa.Pyrfa()
p.createConfigDb("./pyrfa.cfg")
p.setDebugMode(True)
p.acquireSession("Session1")
p.createOMMConsumer()
p.login()
p.directoryRequest()
p.dictionaryRequest()

p.marketByPriceRequest("ANZ.CHA");

end = False
while not end:
    try:
        for updates in p.dispatchEventQueue(0):
            print "========================"
            print updates
    except:
        end = True
del p
