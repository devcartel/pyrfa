#!/usr/bin/python
#
# - Subscribe to multiple RICs, using local dictionary, debug mode is manually off.
# - marketPriceCloseAllRequest is called but not neccessary.
#
# update message format:
#     (('NIP', 'EUR=', {'ASK': '0.999', 'ASK_TIME': '13:41:32:120', 'BID': '0.988', 'BID_NET_CH': '0.0041'}), (...))
#
import sys
sys.path.append('../lib')

import pyrfa
p = pyrfa.Pyrfa()
p.createConfigDb("./pyrfa.cfg")
p.acquireSession("Session1")
p.createOMMConsumer()
p.login()
p.directoryRequest()
p.dictionaryRequest()
p.marketPriceRequest("JPY=,EUR=")

end = False
while not end:
    try:
        updates = p.dispatchEventQueue(100)
    except KeyboardInterrupt:
        end = True
    if updates:
        print ""
        for u in updates:
            print u[0],"-",u[1]
            if type(u[2]) is str:
                print u[2].rjust(15)
            else:
                for k,v in u[2].items():
                    print k.rjust(15),v
            print ""

p.marketPriceCloseAllRequest()
