#!/usr/bin/python
#
# Request for symbolList. Currently RFA only support refresh messages
# for symbolList. Hence, polling is required and symbolListRequest is called
# internally by getSymbolList.
#
# Sample:
#   ('NIP', '0#BMD', 'REFRESH')
#   ('NIP', '0#BMD', 'ADD', ('FKLI', {}))
#   ('NIP', '0#BMD', 'ADD', ('FCPO', {'PROD_PERM': 10, 'PROV_SYMB': 'MY439483'}))
#
import threading
import pyrfa

p = pyrfa.Pyrfa()
p.createConfigDb("./pyrfa.cfg")
p.acquireSession("Session3")
p.createOMMConsumer()

p.login()

# Must call directory/dictinary request first
p.directoryRequest()
p.dictionaryRequest()

RIC = "0#BMD"
symbolList = p.getSymbolList(RIC)

print "\n=======\n",RIC,"\n======="
print symbolList.replace(" ","\n")

del p