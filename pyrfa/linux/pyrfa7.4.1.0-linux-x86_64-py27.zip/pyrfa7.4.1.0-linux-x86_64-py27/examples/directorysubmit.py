#!/usr/bin/python
#
# Non-interactive (full cached) publisher for market price domain
#
import threading
import sys
import random
import time
sys.path.append('../lib')
execfile('./utils/every.py')

import pyrfa
p = pyrfa.Pyrfa()
p.createConfigDb("./pyrfa.cfg")
p.setDebugMode(True)
p.acquireSession("Session4")
p.createOMMProvider()

p.login()

p.dictionaryRequest()

p.submitDirectory()

time.sleep(10)

p.submitDirectory("6")

time.sleep(10)

p.submitDirectory("7,8")

time.sleep(10)