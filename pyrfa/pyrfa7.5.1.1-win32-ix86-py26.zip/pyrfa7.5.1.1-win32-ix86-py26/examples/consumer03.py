#!/usr/bin/python
#
# - show how to set/access dict from update tuples
#
# update message format:
#     (('NIP', 'EUR=', {'ASK': '0.999', 'ASK_TIME': '13:41:32:120', 'BID': '0.988', 'BID_NET_CH': '0.0041'}), (...))
# access with
#     NIP['EUR=']['ASK']
#
import threading
import sys
import pprint
sys.path.append('../lib')

import pyrfa
p = pyrfa.Pyrfa()
p.createConfigDb("./pyrfa.cfg")
p.setDebugMode(False)
p.acquireSession("Session1")
p.createOMMConsumer()

p.login()

p.directoryRequest()
p.dictionaryRequest()

p.marketPriceRequest("C.N,EUR=")

# run for N millisecs, parse updates and display on stdout
def stop():
    global end
    end = True
    
end = False
t = threading.Timer(3, stop)
t.start()

while not end:
    updates = p.dispatchEventQueue(100)
    if updates:
        print "\n\n========== update ================="
        print updates
        print ""
        for u in updates:
            print u[0],"-",u[1]
            # creat an empty dict
            if u[0] not in globals():
                exec(u[0] + " = dict()")
            
            # update ric field cache
            # if recieve REFRESH then clear all FIDs
            if type(u[2]) is str:
                print u[2].rjust(15)
                exec(u[0] + "['" + u[1] + "'] = {}")
            else:
                for k,v in u[2].items():
                    print k.rjust(15),v
                eval(u[0] + "['" + u[1] + "'].update(u[2])")
        print "============ cached dict %s ===============" % u[0]
        eval('pprint.pprint(' + u[0] + ')')

p.marketPriceCloseAllRequest()
