#!/usr/bin/python
#
# This file illustrates the example how to request OMMlevel2 data using marketByOrderRequest
# The sample published data is mentioned below:
#
# Sample:
#   ('NIP', 'ANZ.AX', 'REFRESH')
#   ('NIP', 'ANZ.AX', 'ADD', ('538993C200035057B', {'ORDER_SIDE': 'BID', 
#   'ORDER_TONE': '', 'SEQNUM_QT': 328.0, 'ORDER_PRC': 20.72, 'CHG_REAS': 10.0, 'ORDER_SIZE': 977.0, 'EX_ORD_TYP': 0.0}))
#   (('NIP','ANZ.AX','UPDATE',('538993C200035057B',{'ORDER_SIDE':'BID','SEQNUM_QT':779,
#   'ORDER_PRC':20.705,'CHG_REAS':10,'ORDER_SIZE':754,'EX_ORD_TYP':0})))
#
import threading
import sys
sys.path.append('../lib')

import pyrfa
p = pyrfa.Pyrfa()
p.createConfigDb("./pyrfa.cfg")
p.setDebugMode(True)
p.acquireSession("Session1")
p.createOMMConsumer()

p.login()

p.directoryRequest()
p.dictionaryRequest()

p.marketByOrderRequest("ANZ.AX");

# run for N millisecs, parse updates and display on stdout
def stop():
	global end
	end = True
	
end = False
t = threading.Timer(5, stop)
t.start()
while not end:
    for updates in p.dispatchEventQueue(0):
        print "========================"
        print updates
del p