# Copyright (C) 2012-2014 DevCartel Co.,Ltd.
# Author: wiwat.t@devcartel.com

__version__ = '7.6.1.0'

from pyrfa import *
