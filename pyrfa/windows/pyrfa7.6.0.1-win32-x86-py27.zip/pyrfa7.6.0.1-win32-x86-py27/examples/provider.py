#!/usr/bin/python
#
# Non-interactive (full cached) publisher for market price domain
#
import threading
import sys
import random
sys.path.append('../lib')
execfile('./utils/every.py')

import pyrfa
p = pyrfa.Pyrfa()
p.createConfigDb("./pyrfa.cfg")
p.setDebugMode(True)
p.acquireSession("Session4")
p.createOMMProvider()
p.login()
p.dictionaryRequest()

# publish data every x ms.
IMAGES = ('EUR=', {'RDNDISPLAY':200, 'RDN_EXCHID':155, 'BID':0.988, 'ASK':0.999, 'DIVPAYDATE':'20110623'})
IMAGES = IMAGES,('C.N',  {'RDNDISPLAY':200, 'RDN_EXCHID':'NAS', 'OFFCL_CODE':'isin1234XYZ', 'BID':4.23, 'DIVPAYDATE':'20110623', 'OPEN_TIME':'09:00:01.000'})
p.marketPriceSubmit(IMAGES)

# updates every x secs.
vol = 1000
def update():
    global p
    global vol
    vol += 1
    price = 4 + round(random.random(),3)
    UPDATES = ('C.N', {'ACVOL_1':vol, 'TRDPRC_1':price})
    UPDATES = UPDATES,('EUR=', {'BID_NET_CH':0.0041, 'BID':0.988, 'ASK':0.999,'ASK_TIME':'now'})
    p.marketPriceSubmit(UPDATES)

loop = every(1, update)
end = False
try:
    while not end:
        pass
except KeyboardInterrupt:
    loop.stop()
    end = True
 