#!/usr/bin/python

from distutils.core import setup
import platform

setup(name='pyrfa',
      version='7.6.0',
      description='Python module For Thomson Reuters Robust Foundation API (RFA)',
      author='DevCartel Company Limited',
      author_email='support@devcartel.com',
      url='http://www.devcartel.com/pyrfa',
      packages=['pyrfa'],
      package_dir = {'': 'lib'},
      package_data={'pyrfa': [('pyrfa.pyd' if platform.system() == 'Windows' else 'pyrfa.so')]}
     )