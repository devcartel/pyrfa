#!/usr/bin/python
#
# Non-interactive (full cached) publisher for market price domain
#
import threading
import random
execfile('./utils/every.py')
import pyrfa

p = pyrfa.Pyrfa()
p.createConfigDb("./pyrfa.cfg")
p.setDebugMode(True)
p.acquireSession("Session4")
p.createOMMProvider()

p.login()

p.dictionaryRequest()

########################################
# order book publisher
########################################
# add orders
ORDERS = (('ANZ.AX', '538993C200035057B', {'ORDER_PRC': '20.260', 'ORDER_SIZE':50, 'ORDER_SIDE':'BID', 'SEQNUM_QT':2744, 'EX_ORD_TYP':0, 'CHG_REAS':6,'ORDER_TONE':''}),)
ORDERS += (('ANZ.AX', '538993C200083483B', {'ORDER_PRC': '20.280', 'ORDER_SIZE':100, 'ORDER_SIDE':'ASK', 'SEQNUM_QT':2744, 'EX_ORD_TYP':0, 'CHG_REAS':6,'ORDER_TONE':''}),)

p.marketByOrderSubmit('ADD', ORDERS)

########################################
# market depth publisher
########################################
# add market depths
DEPTHS = (('ANZ.CHA', '201000B', {'ORDER_PRC': '20.1000', 'ORDER_SIDE':'BID', 'ORDER_SIZE':'1300', 'NO_ORD':13, 'QUOTIM_MS':16987567,'ORDER_TONE':''}),)
DEPTHS += (('ANZ.CHA', '201000B', {'ORDER_PRC': '20.2000', 'ORDER_SIDE':'BID', 'ORDER_SIZE':'100', 'NO_ORD':13, 'QUOTIM_MS':16987567,'ORDER_TONE':''}),)
DEPTHS += (('ANZ.CHA', '210000B', {'ORDER_PRC': '21.0000', 'ORDER_SIDE':'ASK', 'ORDER_SIZE':'500', 'NO_ORD':13, 'QUOTIM_MS':16987567,'ORDER_TONE':''}),)
p.marketByPriceSubmit('ADD',DEPTHS)

# run for x secs.
def stop():
    global end
    global loop
    end = True
    loop.stop()
#t = threading.Timer(10, stop)
#t.start()

# updates every x secs.
size = 100
no_ord = 14
def update():
    global p
    global size
    global no_ord
    size += 100
    no_ord += 1
    price = 20 + round(random.random(),3)
    #update order
    ORDERS_UPDATE = ('ANZ.AX', '538993C200083483B', {'ORDER_PRC': price, 'ORDER_SIZE':size, 'ORDER_SIDE':'BID', 'SEQNUM_QT':2745, 'EX_ORD_TYP':0, 'CHG_REAS':6,'ORDER_TONE':''})
    p.marketByOrderSubmit('UPDATE',ORDERS_UPDATE)
    
    #update depth
    DEPTHS_UPDATE = ('ANZ.CHA', '210000B', {'ORDER_PRC': price , 'ORDER_SIDE':'BID', 'ORDER_SIZE':size, 'NO_ORD':no_ord, 'QUOTIM_MS':16987567,'ORDER_TONE':''})
    p.marketByPriceSubmit('UPDATE',DEPTHS_UPDATE)    
loop = every(1, update)

# event loop
end = False
while not end:
    pass
 