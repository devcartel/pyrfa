#!/usr/bin/python
#
# Non-interactive (full cached) publisher for market price domain
#
import threading
import pyrfa

p = pyrfa.Pyrfa()
p.createConfigDb("./pyrfa.cfg")
p.setDebugMode(True)
p.acquireSession("Session4")
p.createOMMProvider()

p.login()

p.dictionaryRequest()

# publish data every x ms.
SYMBOLLIST = (('0#BMD', 'FCPO', {'PROD_PERM':10, 'PROV_SYMB':'MY439483'}),)
SYMBOLLIST += (('0#BMD', 'FKLI', {}),)
SYMBOLLIST += (('0#BMD', 'FKLQ', {}),)
SYMBOLLIST += (('0#BMD', 'FKLT', {}),)
SYMBOLLIST += (('0#BMD', 'FKLP', {}),)
SYMBOLLIST += (('0#BMD', 'FKLL', {}),)
SYMBOLLIST += (('0#BMD', 'FKLM', {}),)

p.symbolListSubmit("ADD",SYMBOLLIST)

time.sleep(40)

SYMBOLLISTDELETE = ('0#BMD', 'FCPO', {})
p.symbolListSubmit("DELETE",SYMBOLLISTDELETE)

while True:
    pass
 