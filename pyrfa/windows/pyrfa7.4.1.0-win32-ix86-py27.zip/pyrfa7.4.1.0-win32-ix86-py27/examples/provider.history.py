#!/usr/bin/python
#
# Non-interactive (full cached) publisher for history domain
# HISTORY provides full indexed time series
#
import threading
import sys
import random
sys.path.append('../lib')
execfile('./utils/every.py')

import pyrfa
p = pyrfa.Pyrfa()
p.createConfigDb("./pyrfa.cfg")
p.setDebugMode(True)
p.acquireSession("Session4")
p.createOMMProvider()
p.login()
p.dictionaryRequest()

UPDATES = ('tANZ.AX', {'TRDPRC_1':40.124, 'SALTIM':'now', 'TRADE_ID':'123456789', 'BID_ORD_ID':'5307FBL20AL7B', 'ASK_ORD_ID':'5307FBL20BN8A'})
UPDATES = UPDATES,('tBHP.AX', {'TRDPRC_1':25.234, 'SALTIM':'now', 'TRADE_ID':'987654321', 'BID_ORD_ID':'5307FBL2XXXXB', 'ASK_ORD_ID':'5307FBL2YYYYA'})
p.historySubmit(UPDATES)

count = 0
def update():
    global p
    global UPDATES
    global count
    if count < 100:
        p.historySubmit(UPDATES)
        count += 1

every(1, update)

end = False
while not end:
    pass