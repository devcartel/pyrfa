#!/usr/bin/python

from distutils.core import setup
import platform

version = '7.6.1'
if platform.system() == 'Windows':
    packagefile = 'pyrfa.pyd'
else:
    packagefile = 'pyrfa.so'

setup(name = 'pyrfa',
      version = version,
      description = 'Python module For Thomson Reuters Robust Foundation API (RFA)',
      author = 'DevCartel Company Limited',
      author_email = 'support@devcartel.com',
      url = 'http://www.devcartel.com/pyrfa',
      packages = ['pyrfa'],
      package_dir = {'': 'lib'},
      package_data = {'pyrfa': [packagefile]}
     )
    