#!/usr/bin/python
#
# Like a consumer but no updates after refresh messages
#
import threading
import pyrfa

p = pyrfa.Pyrfa()
p.createConfigDb("./pyrfa.cfg")
p.acquireSession("Session1")
p.createOMMConsumer()
p.login()
p.directoryRequest()
p.dictionaryRequest()

rics = "JPY=,EUR="
p.setInteractionType("snapshot")
p.marketPriceRequest(rics)

# run until all images received or timeout
def stop():
    global timeout
    timeout = True
    
timeout = False
t = threading.Timer(10, stop)
t.start()

refresh_received = 0
while not timeout and refresh_received < len(rics.split(',')):
    for u in p.dispatchEventQueue():
        print u[0],"-",u[1]
        if type(u[2]) is str:
            print u[2].rjust(15)
            refresh_received += 1
        else:
            for k,v in u[2].items():
                print k.rjust(15),v
        print ""

t.cancel()