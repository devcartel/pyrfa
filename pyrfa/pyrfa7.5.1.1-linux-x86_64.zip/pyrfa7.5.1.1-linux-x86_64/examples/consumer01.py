#!/usr/bin/python
#
# Subscribe to market data for n seconds, dump raw update from dispatching
# Notice that update is in Python tuple and dict format
#
# update message format:
#     (('NIP', 'EUR=', {'ASK': '0.999', 'ASK_TIME': '13:41:32:120', 'BID': '0.988', 'BID_NET_CH': '0.0041'}), (...))
#
import threading
import sys
sys.path.append('../lib')

import pyrfa
p = pyrfa.Pyrfa()
p.createConfigDb("./pyrfa.cfg")
p.acquireSession("Session1")
p.createOMMConsumer()

p.login()

p.directoryRequest()
p.dictionaryRequest()

p.marketPriceRequest("C.N")

# run for N millisecs, parse updates and display on stdout
def stop():
    global end
    end = True
    
end = False
t = threading.Timer(10, stop)
t.start()

while not end:
    updates = p.dispatchEventQueue(100)
    if updates:
        print updates

del p