#!/usr/bin/python
import threading
import sys
sys.path.append('../lib')

import pyrfa
p = pyrfa.Pyrfa()
p.createConfigDb("./pyrfa.cfg")
p.setDebugMode(True)
p.acquireSession("Session2")
p.createOMMConsumer()

p.login()

p.directoryRequest()