#!/usr/bin/python
#
# - Subscribe to multiple RICs, using local dictionary, debug mode is manually off.
# - We can manually perform marketPriceCloseAllRequest too but not neccessary.
#
# update message format:
#     (('NIP', 'EUR=', {'ASK': '0.999', 'ASK_TIME': '13:41:32:120', 'BID': '0.988', 'BID_NET_CH': '0.0041'}), (...))
#
import threading
import sys
sys.path.append('../lib')

import pyrfa
p = pyrfa.Pyrfa()
p.createConfigDb("./pyrfa.cfg")
p.setDebugMode(True)
p.acquireSession("Session1")
p.createOMMConsumer()

p.login()

p.directoryRequest()
p.dictionaryRequest()

p.marketPriceRequest("C.N,EUR=")

# run for N millisecs, parse updates and display on stdout
def stop():
    global end
    end = True
    
end = False
t = threading.Timer(3, stop)
t.start()

while not end:
    updates = p.dispatchEventQueue(100)
    if updates:
        print ""
        for u in updates:
            print u[0],"-",u[1]
            if type(u[2]) is str:
                print u[2].rjust(15)
            else:
                for k,v in u[2].items():
                    print k.rjust(15),v
            print ""

# explicitly call close request
p.marketPriceCloseAllRequest()
